import { saludar } from './js/componentes.js';
import './styles.css';



const nombre = 'Fernando';

saludar( nombre );
