# webpack-configuracion-estandar
Fin de la sección 8


## Nota
Recuerden que para reconstruir los módulos de node deben de ejecutar este comando

```
npm install
```

Y para crear nuevamente el DIST

```
npm start
```
